// This code was written as part of the bookclub application project
// to fulfill the requirements of CIS530 at Bellevue University
// Kylie Gregory - 5/22/2022

package com.bookclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookclubApplicationTests {

	@Test
	void contextLoads() {
	}

}
