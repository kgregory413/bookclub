package com.bookclub.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class WishlistItem {

    // Give the class two private properties for isbn and title.
    //Add a @NotNull and @NotEmpty decorator to each property with a message of
    // “<PropertyName is a required field.”>.

    @NotNull
    @NotEmpty(message = "ISBN is a required field.")
    private String isbn;

    @NotNull
    @NotEmpty(message = "Title is a required field.")
    private String title;

    public WishlistItem() {}

    // Give the class two constructors, a default and one with two parameters for isbn and
    // title.

    public WishlistItem(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    // Provide the class with getter/setter methods.

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    // Override the classes toString method and return string formatted as
    // “WishlistItem{isbn=<isbnValue>, title=<titleValue>}
    
    @Override
    public String toString() {
        return String.format("WishlistItem{isbn=%s, title=%s}", isbn, title);
    }
}